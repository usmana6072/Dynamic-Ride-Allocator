import java.util.*;
public class DriverMinHeap{
    static ArrayList<Driver> heap = new ArrayList<>();

    public static void insert(Driver driver){
        heap.add(driver);
        heapifyUp(heap.size()-1);
    }

    public static void insertAll(ArrayList<Driver> drivers){
        for (Driver d : drivers)
            insert(d);
    }

    public static Driver extractMin(){
        if (heap.isEmpty())
            return null;
        Driver min=heap.get(0);
        Driver last=heap.remove(heap.size() - 1);
        if (!heap.isEmpty()){
            heap.set(0,last);
            heapifyDown(0);
        }
        return min;
    }

    public static Driver peekMin(){
        return heap.isEmpty()?null:heap.get(0);
    }

    public static ArrayList<Driver> getAllInHeap(){
        return new ArrayList<>(heap);
    }

    public static void clear(){
        heap.clear();
    }

    public static boolean isEmpty(){
        return heap.isEmpty();
    }

    public static int size(){
        return heap.size();
    }
    public static void swap(int i, int j){
        Driver temp=heap.get(i);
        heap.set(i,heap.get(j));
        heap.set(j,temp);
    }
    public static void heapifyUp(int i){
    }

    public static void heapifyDown(int i){

    }

}