import java.util.*;
public class CityGraph {
    static Map<String, List<Road>> adjacencyList = new LinkedHashMap<>();
    static ArrayList<String> allLocations = new ArrayList<>();

    public static boolean addLocation(String location){
        location=location.trim();
        if (location.isEmpty())
            return false;
        if (adjacencyList.containsKey(location))
            return false;
        adjacencyList.put(location,new ArrayList<>());
        allLocations.add(location);
        return true;
    }

    public static String addRoad(String from,String to,double distance){
        from=from.trim();
        to=to.trim();

        if (from.equalsIgnoreCase(to))
            return "SAME NODE";
        if (!adjacencyList.containsKey(from))
            addLocation(from);
        if (!adjacencyList.containsKey(to))
            addLocation(to);
        for (Road r : adjacencyList.get(from)){
            if (r.destination.equals(to))
                return "ALREADY EXISTS";
        }
        adjacencyList.get(from).add(new Road(to,distance));
        adjacencyList.get(to).add(new Road(from,distance));
        return "OK";
    }
    public static boolean removeLocation(String location){
        if (!adjacencyList.containsKey(location))
            return false;
        for (String node : adjacencyList.keySet())
            adjacencyList.get(node).removeIf(r -> r.destination.equals(location));
        adjacencyList.remove(location);
        allLocations.remove(location);
        return true;
    }

    public static boolean locationExists(String location){
        return adjacencyList.containsKey(location);
    }

    public static ArrayList<String> getAllLocations(){
        return allLocations;
    }

    public static ArrayList<String> getNeighbours(String location){
        return null;
    }

    public static double getRoadDistance(String from, String to){
        return 0.00;
    }

    public static ArrayList<String> getAllRoadsAsStrings(){
        return null;
    }

    public static void clearGraph(){
        adjacencyList.clear();
        allLocations.clear();
    }
}