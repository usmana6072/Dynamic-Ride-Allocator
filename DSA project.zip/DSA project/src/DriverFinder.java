import java.util.*;
public class DriverFinder {
    static ArrayList<Driver> allDrivers = new ArrayList<>();

    public static String addDriver(String name, String location){
        name=name.trim();
        location=location.trim();
        if (!CityGraph.locationExists(location))
            return "LOCATION NOT FOUND";
        for (Driver d:allDrivers)
            if (d.name.equalsIgnoreCase(name))
                return "DUPLICATE NAME";
        allDrivers.add(new Driver(name, location));
        return "OK";
    }

    public static boolean removeDriver(String name){
        boolean removed = allDrivers.removeIf(d -> d.name.equalsIgnoreCase(name));
        return removed;
    }

    public static String updateDriverLocation(String name,String newLocation){
        if (!CityGraph.locationExists(newLocation))
            return "LOCATION NOT FOUND";
        for (Driver d : allDrivers) {
            if (d.name.equalsIgnoreCase(name)){
                d.location = newLocation;
                return "OK";
            }
        }
        return "DRIVER NOT FOUND";
    }

    public static ArrayList<Driver> getAllDrivers(){
        return allDrivers;
    }

    public static ArrayList<Driver> getAvailableDrivers(){
        ArrayList<Driver> available=new ArrayList<>();
        for (Driver d:allDrivers)
            if (d.available)
                available.add(d);
        return available;
    }
    public static ArrayList<Driver> findNearbyDrivers(String riderLocation, int maxHops){
        return null;
    }
}
